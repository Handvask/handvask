---
name: Feature request
about: Suggest an idea for this project
---


**What language and solver does this apply to?**
All, Python, Java, C#, C++ / CP-SAT, Routing, Linear Solver

**Describe the problem you are trying to solve.**

**Describe the solution you'd like**

**Describe alternatives you've considered**

**Additional context**
Add any other context or screenshots about the feature request here.

