# Java examples
The following examples showcase how to use the different Operations Research libraries.

# Execution
Running the examples will involve building them, then running them.   
You can run the following command from the **top** directory:
```shell
make build SOURCE=examples/java/<example>.java
make run SOURCE=examples/java/<example>.java
```
